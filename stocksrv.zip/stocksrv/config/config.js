module.exports = {
	
	
	version             : "1.0",	
	urlServer		: "http://localhost:1337/", 
	urlServerStarossa 	: "http://santarossa.ddns.net:1337/"	
	
	
};