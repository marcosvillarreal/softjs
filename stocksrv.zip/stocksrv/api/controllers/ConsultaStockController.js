module.exports = {
	index: function (req, res) {
	      		
	    var strcodbarra = String(req.param('intcodbarra','9999999999999'));
		var strnombre   = String(req.param('strnombre',''));
		var strempresa   = String(req.param('idempresa',''));
		
		sails.log.debug("Solicita Código:",strcodbarra);
		sails.log.debug("Solicita Nombre:",strnombre);
		sails.log.debug("Empresa:",strempresa);
		
		if (strnombre.trim().length<3){strnombre=''} 
			else {
				var palabras = strnombre.split(" ");
		}
		
		var idempresa = parseInt(strempresa);
		
		const config = [
			
			{
				user: 'sa',
				server: 'distribuidorakleja.ddns.net', // You can use 'localhost\\instance' to connect to named instance
				database: 'kleja',
				password:'Cf3485',
				port: 1170,
				options: {
					encrypt: false // Use this if you're on Windows Azure
				}
			
			},
			{
				user: 'sa',
				password: 'Cf3485',
				server: 'santarossa.ddns.net', // You can use 'localhost\\instance' to connect to named instance
				database: 'datos',
				port: 1171,
				options: {
					encrypt: false // Use this if you're on Windows Azure
				}	
			},
			{
				user: 'sa',
				password: 'Cf3485',
				server: 'elfortincdp.ddns.net', // You can use 'localhost\\instance' to connect to named instance
				database: 'fortin',
				port: 1170,
				options: {
					encrypt: false // Use this if you're on Windows Azure
				}	
			}
			
			
		]
		
		var sqlQ = "" 
		switch (idempresa){
			case 1: {
				sqlQ     = sqlQ + "select a.numero,isnull(s.subnumero,0) as subnumero "
				sqlQ     = sqlQ + ",a.nombre as nombre "
				sqlQ     = sqlQ + ",a.unibulto "
				sqlQ     = sqlQ + ",'UNIDADES' as univenta "
				sqlQ     = sqlQ + ",isnull(s.nombre,'') as nomvariedad "
				sqlQ     = sqlQ + "from producto a left join subproducto s on s.idarticulo=a.id "
			};
			case 2: {
				sqlQ     = sqlQ + "select a.numero,isnull(s.subnumero,0) as subnumero "
				sqlQ     = sqlQ + ",a.nombre as nombre "
				sqlQ     = sqlQ + ",a.unibulto "
				sqlQ     = sqlQ + ",'UNIDADES' as univenta "
				sqlQ     = sqlQ + ",isnull(s.nombre,'') as nomvariedad "
				sqlQ     = sqlQ + "from producto a left join subproducto s on s.idarticulo=a.id "
			};
			case 3: {
				sqlQ     = sqlQ + "select a.numero,isnull(s.subnumero,0) as subnumero "
				sqlQ     = sqlQ + ",a.nombre as nombre "
				sqlQ     = sqlQ + ",a.unibulto "
				sqlQ     = sqlQ + ",'UNIDADES' as univenta "
				sqlQ     = sqlQ + ",isnull(s.nombre,'') as nomvariedad "
				sqlQ     = sqlQ + "from producto a left join subproducto s on s.idarticulo=a.id "
			};
		}		
		if(strnombre.trim().length>1&&strnombre!=null){		
		    strCondicion = "(";
			strSep       = "";
			for (var i = 0; i < palabras.length; i+=1) {
				strCondicion = strCondicion + strSep +"a.nombre like'%"+ palabras[i]+"%'";
				strSep       = " and ";										
			}
		    strCondicion = strCondicion + ")";
			sails.log.debug("sql:",strCondicion)				
		    sqlQ = sqlQ + "where (a.espromocion=0 and a.idestado=1 and "+strCondicion+") order by a.nombre";		  
	    } else {
			if(strcodbarra.trim().length<7){
			   sqlQ = sqlQ + " where (a.espromocion=0 and a.idestado=1 and ( a.numero="+strcodbarra+" or a.codalfa='"+strcodbarra+"'))";		  
			} else {
				sqlQ = sqlQ + "where (a.espromocion=0 and a.idestado=1 and (a.codbarra13 like '%"+strcodbarra+"%' or s.codigo like '%"+strcodbarra+"%' or a.codalfa like '%"+strcodbarra+"%' or a.numero like '%"+strcodbarra+"%'))";
			}			
		}	
		
		
		//sails.log.debug("sql:",sqlQ);
		//sails.log.debug(config[idempresa]);
		
		idempresa = idempresa - 1; //Es un arreglo y arranca en 0
		
		const sql = require('mssql')
		sql.connect(config[idempresa]).then(pool => {
			// Query
			return pool.request().query(sqlQ)
		}).then(result => {			
		    sql.close()
			res.writeHead(200, { "Content-Type": "application/json" });
			if(result){ 
			    //sails.log.debug("sql:",sqlQ);
				res.write(JSON.stringify(result.recordsets[0]));					
				//res.write(result);					
		    };    				
		    //console.dir(result)
			res.end();																	
		}).catch(err => {
			sails.log.debug("ERROR:","error en conexón");
		    sql.close()
			res.end();								
		})		
		
				
    }  
};


  