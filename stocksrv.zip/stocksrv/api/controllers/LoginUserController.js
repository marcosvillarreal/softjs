

module.exports = {
	index: function (req, res) {

    datastore : "sqserver";

    sails.log.debug("Entro");

	  var cUserName = req.param('username','');
		var cPassword = req.param('password','');

		sails.log.debug("Solicita Usuario:",cUserName);


	const objConfig = {
			
			user: 'sa',
			password: 'pre!Venta11',
			server: 'preventa.cloudapp.net', // You can use 'localhost\\instance' to connect to named instance
			database: 'gestionweb',
			port: 49904,
			options: {
				encrypt: false // Use this if you're on Windows Azure
			}	
			
			
			
		}
		

    /*
    const config = {
      user: process.env.DB_USER,
      password: process.env.DB_PASSWD,
      server: process.env.DB_HOST, // You can use 'localhost\\instance' to connect to named instance
      database: process.env.DB_NAME,
      port: process.env.DB_PORT,
      options: {
        encrypt: process.env.DB_ENCRYPT // Use this if you're on Windows Azure
      }
    }
    sails.log.debug("sql host:",process.env.DB_HOST);
    */

    var sqlQ = "",sqlW = ""


    sqlQ     = sqlQ + "SELECT CsrUsuario.* From users as CsrUsuario "

    sqlW = "isnull(CsrUsuario.activo,1)=1 ";

    if(cUserName.trim().length>0){
      sqlW = sqlW + " AND CsrUsuario.username = '"+cUserName+"'";
    }
    if(cPassword.trim().length>0){
      sqlW = sqlW + " AND CsrUsuario.password = '"+cPassword+"'";
    }
    sqlQ = sqlQ + " WHERE ("+ sqlW + ")";



		const sql = require('mssql')
		sql.connect(objConfig).then(pool => {
			// Query
			return pool.request().query(sqlQ)
		}).then(result => {
		    sql.close()
			res.writeHead(200, { "Content-Type": "application/json" });
			if(result){
			    sails.log.debug("sql:",sqlQ);
				res.write(JSON.stringify(result.recordsets[0]));
				//res.write(result);
		    };
		    //console.dir(result)
			res.end();
		}).catch(err => {
			sails.log.debug("ERROR:","error en conexón",err.message);
		    sql.close()
			res.end();
		})


  }
};


