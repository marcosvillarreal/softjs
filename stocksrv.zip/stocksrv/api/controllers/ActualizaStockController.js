module.exports = {
	index: function (req, res) {
	      		
	    var listaStock  = JSON.parse(req.param('listaStock',{}));
		var strdispo    = String(req.param('dispo','desconocido'));		
		
		const config = {
			user: 'sa',
			password: 'Cf3485',
			server: 'santarossa.ddns.net', // You can use 'localhost\\instance' to connect to named instance
			database: 'datos',
			port: 1171,
			options: {
				encrypt: false // Use this if you're on Windows Azure
			}			
		}
		const sql = require('mssql')
		
		var sqlQ   = "DELETE FROM stockleido where dispo='" + strdispo+"'"
		sails.log.debug(sqlQ);
		
		sql.connect(config).then(pool => {
			// Query
			return pool.request().query(sqlQ)
		}).then(result => {			
		
		        sails.log.debug("Ok el primero");
				if(listaStock.length==0){
					sql.close()
					res.writeHead(200, { "Content-Type": "application/json" });
					res.write("OK");							    
					res.end();																	
				} else {
					var sqlQ   = "INSERT INTO stockleido (codigo,subcodigo,unidad,dispo,bultos) VALUES " 
					var strSep = ""
					for (var i=0; i<listaStock.length; i++) { 
						//sails.log.debug(listaStock[i].numero+" => "+listaStock[i].cantidad)	
						sqlQ     = sqlQ +strSep + "(" + listaStock[i].numero+","+listaStock[i].subnumero+","+listaStock[i].cantidad+",'"+strdispo+"',"+listaStock[i].bultos+")"
						strSep   = ","
					}	
	
					sails.log.debug("sql:",sqlQ);				
					//sql.close()
					sql.connect(config).then(pool => {
						// Query
						return pool.request().query(sqlQ)
					}).then(result => {			
						sql.close()
						res.writeHead(200, { "Content-Type": "application/json" });
						res.write("OK");							    
						res.end();																	
					}).catch(err => {
						sails.log.debug("ERROR:","error en conexión 2");
						sql.close()
						res.end();								
					})		
				}
		
		}).catch(err => {
			sails.log.debug("ERROR:","error en conexón 1");
		    sql.close()
			res.end();								
		})		
				
		
				
    }  
};


  