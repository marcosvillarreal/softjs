import { thumbnail } from './thumbnail.js'
import { multistore } from './multistore.js'

export {
  thumbnail,
  multistore
}
