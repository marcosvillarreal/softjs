export default interface AttributeState {
  list_by_code: any,
  list_by_id: any,
  labels: any,
  blacklist: any[]
}
