export default interface AppliedCoupon {
  code: string,
  discount: number
}
