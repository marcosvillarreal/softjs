export default interface CmsHierarchyState {
  items: any[]
}
