export const getters = {
  getCurrentRoute: (state) => state.currentRoute,
  isBackRoute: (state) => state.isBackRoute,
  getPrevRoute: (state) => state.prevRoute
}
