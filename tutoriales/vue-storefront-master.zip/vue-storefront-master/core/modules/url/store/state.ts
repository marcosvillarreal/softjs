import { UrlState } from '../types/UrlState'

export const state: UrlState = {
  dispatcherMap: {},
  currentRoute: {},
  prevRoute: {},
  isBackRoute: false
}
