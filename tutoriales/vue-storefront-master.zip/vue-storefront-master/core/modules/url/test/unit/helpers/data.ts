let product = {
  sku: 'MSH09',
  slug: 'troy-yoga-short-994',
  url_path: 'men/bottoms-men/shorts-men/shorts-19/troy-yoga-short-994.html',
  type_id: 'configurable',
  parentSku: 'MSH09'
}

export {
  product
}
