export default interface OrderState {
  last_order_confirmation: any,
  session_order_hashes: string[]
}
