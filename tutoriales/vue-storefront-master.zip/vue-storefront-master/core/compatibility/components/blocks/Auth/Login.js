import { Login } from '@vue-storefront/core/modules/user/components/Login'
export default {
  mixins: [Login]
}
