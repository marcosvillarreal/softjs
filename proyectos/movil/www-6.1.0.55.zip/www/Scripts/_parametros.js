﻿var preventamobile = preventamobile || {};

preventamobile.parametros = preventamobile.parametros || { indicadorProgreso: "" };